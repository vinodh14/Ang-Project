/* global angular */
(function() {
  
  'use strict';

  var app = angular.module('formlyExample', ['formly', 'formlyBootstrap', 'xeditable']);

  app.run(function(editableOptions, formlyConfig) {
    editableOptions.theme = 'bs3';
    
    formlyConfig.setType({
      extends: 'input',
      template: '<div><span editable-text="model[options.key]" e-name="{{::id}}">{{ model[options.key] || "empty" }}</span></div>',
      name: 'editableInput'
    });
  });

  app.controller('MainCtrl', function MainCtrl(formlyVersion) {
    var vm = this;
    // funcation assignment
    vm.onSubmit = onSubmit;

    // variable assignment
    vm.author = { // optionally fill in your info below :-)
      name: 'Kent C. Dodds',
      url: 'https://twitter.com/kentcdodds'
    };
    vm.exampleTitle = 'angular-xeditable integration'; // add this
    vm.env = {
      angularVersion: angular.version.full,
      formlyVersion: formlyVersion
    };

    vm.model = {text: 'This is editable!'};
    vm.options = {};
    
    vm.fields = [
      {
        key: 'text',
        type: 'editableInput',
        templateOptions: {
          label: 'Text'
        }
      }
    ];
    
    vm.originalFields = angular.copy(vm.fields);
    
    // function definition
    function onSubmit() {
      debugger;
      vm.options.updateInitialValue();
      alert(JSON.stringify(vm.model), null, 2);
    }
  });

})();