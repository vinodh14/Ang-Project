  var app = angular.module("app", ["xeditable", "ngMockE2E", "ui.bootstrap", 'ngMaterial', 'ngSanitize', 'ui.select']);

  app.run(function(editableOptions) {
    editableOptions.theme = 'bs3';
  });

  app.controller('Ctrl',['$scope', '$http', function($scope, $http) {
	  
	 $scope.user = {
        "contactId": 1,
        "dateOfBirth": "1986-08-15",
        "firstName": "Bhargav",
        "lastName": "Vandana",
        "middleName": "Naidu",
        "addresses":
        [
            {
                "addressId": 1002,
                "address1": "Hyderabad",
                "address2": "Madhapur",
                "addressType": "Work",
                "country": "India"
            },
            {
                "addressId": 1001,
                "address1": "Hyderabad",
                "address2": "Miyapur Alwyn",
                "addressType": "Home",
                "country": "India"
            }
        ],
		"contactcategories":
        [
            {
                "id": 5,
                "categoryName": "Britisher"
            },
            {
                "id": 2,
                "categoryName": "indian"
            },
            {
                "id": 1,
                "categoryName": "Indian"
            },
            {
                "id": 4,
                "categoryName": "britisher"
            },
            {
                "id": 3,
                "categoryName": "American"
            }
        ]
		
	  }
	  
	  $scope.people = [
		{ name: 'Adam',      email: 'adam@email.com',      age: 12, country: 'United States' },
		{ name: 'Amalie',    email: 'amalie@email.com',    age: 12, country: 'Argentina' },
		{ name: 'Estefanía', email: 'estefania@email.com', age: 21, country: 'Argentina' },
		{ name: 'Adrian',    email: 'adrian@email.com',    age: 21, country: 'Ecuador' },
		{ name: 'Wladimir',  email: 'wladimir@email.com',  age: 30, country: 'Ecuador' },
		{ name: 'Samantha',  email: 'samantha@email.com',  age: 30, country: 'United States' },
		{ name: 'Nicole',    email: 'nicole@email.com',    age: 43, country: 'Colombia' },
		{ name: 'Natasha',   email: 'natasha@email.com',   age: 54, country: 'Ecuador' },
		{ name: 'Michael',   email: 'michael@email.com',   age: 15, country: 'Colombia' },
		{ name: 'Nicolás',   email: 'nicolas@email.com',    age: 43, country: 'Colombia' }
	  ];
	  $scope.multipleDemo = {};
	  $scope.multipleDemo.selectedPeople = [$scope.people[5], $scope.people[4]];	 
	/*$http.get("address-book.json").then(function(response) {
		  console.log(response.data);
        //$scope.user = response.data;
	});	*/
	
    $scope.checkName = function(data) {
      if (data !== 'awesome' && data !== 'error') {
        return "Username should be `awesome` or `error`";
      }else{
		  var data=$scope.user; 
		  console.log(data);
	  }
    };

    $scope.saveUser = function() {
      // $scope.user already updated!
      return $http.post('/saveUser', $scope.user).then(function(err) {
        if(err.field && err.msg) {
          // err like {field: "name", msg: "Server-side error for this username!"} 
          $scope.editableForm.$setError(err.field, err.msg);
        } else { 
          // unknown error
          $scope.editableForm.$setError('name', 'Unknown error!');
        }
      });
    };
  }]);

  // ---------------- mock $http requests --------------------
  app.run(function($httpBackend) {
    $httpBackend.whenGET('/groups').respond([
      {id: 1, text: 'user'},
      {id: 2, text: 'customer'},
      {id: 3, text: 'vip'},
      {id: 4, text: 'admin'}
    ]);

    $httpBackend.whenPOST(/\/saveUser/).respond(function(method, url, data) {
      data = angular.fromJson(data);
      if(data.name === 'error') {
        return [500, {field: 'name', msg: 'Server-side error for this username!'}]; 
      } else {
        return [200, {status: 'ok'}]; 
      }
    });
  });