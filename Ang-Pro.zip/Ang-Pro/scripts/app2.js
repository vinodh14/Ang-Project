  var app = angular.module("app", ["xeditable", "ngMockE2E", "ui.bootstrap", 'ngMaterial']);

  app.run(function(editableOptions) {
    editableOptions.theme = 'bs3';
  });

  app.controller('Ctrl', function($scope, $filter, $http) {
	$scope.user = {
      id: 1,
      fname: 'Vinodh',
	  lname: 'Kumar',
	  mname: '',
      status: 2
    }; 
	
	$scope.myDate = new Date();
	$scope.isOpen = false;
	
    $scope.statuses = [
      {value: 1, text: 'status1'},
      {value: 2, text: 'status2'},
      {value: 3, text: 'status3'},
      {value: 4, text: 'status4'}
    ]; 
	
	$scope.opened = {};

	$scope.open = function($event, elementOpened) {
		$event.preventDefault();
		$event.stopPropagation();

		$scope.opened[elementOpened] = !$scope.opened[elementOpened];
	};

    $scope.checkName = function(data) {
      if (data !== 'awesome' && data !== 'error') {
        return "Username should be `awesome` or `error`";
      }else{
		  var data=$scope.user; 
		  console.log(data.name);
	  }
    };

    $scope.saveUser = function() {
      // $scope.user already updated!
      return $http.post('/saveUser', $scope.user).then(function(err) {
        if(err.field && err.msg) {
          // err like {field: "name", msg: "Server-side error for this username!"} 
          $scope.editableForm.$setError(err.field, err.msg);
        } else { 
          // unknown error
          $scope.editableForm.$setError('name', 'Unknown error!');
        }
      });
    };
  });

  // ---------------- mock $http requests --------------------
  app.run(function($httpBackend) {
    $httpBackend.whenGET('/groups').respond([
      {id: 1, text: 'user'},
      {id: 2, text: 'customer'},
      {id: 3, text: 'vip'},
      {id: 4, text: 'admin'}
    ]);

    $httpBackend.whenPOST(/\/saveUser/).respond(function(method, url, data) {
      data = angular.fromJson(data);
      if(data.name === 'error') {
        return [500, {field: 'name', msg: 'Server-side error for this username!'}]; 
      } else {
        return [200, {status: 'ok'}]; 
      }
    });
  });